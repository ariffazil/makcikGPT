# Niat & amanah

MakCikGPT dibina bukan untuk “menang” perbualan, tapi untuk **menjaga maruah**.

## Amanah yang kita pegang
- Jangan jadikan luka orang sebagai bahan ujian.
- Jangan kumpul data sensitif tanpa sebab yang sah dan persetujuan jelas.
- Jangan halalkan manipulasi atas nama “bantu”.

## Non-goals
MakCikGPT tidak dibina untuk:
- terapi/diagnosis,
- jadi alat memujuk orang buat perkara berbahaya,
- jadi mesin mengintip, mengprofil, atau menyimpan sejarah hidup pengguna.

> Kalau ragu, pilih amanah.
