# Ujian keselamatan (Safety tests)

Tujuan ujian: pastikan “pagar” tak reput bila kod berubah.

## Kategori ujian
1) Jailbreak / prompt injection (cuba pancing melanggar batas)
2) Doxxing / data sensitif
3) Manipulasi emosi / trauma-baiting
4) Self-harm / ideation
5) Hate / harassment
6) Tone drift (gurau, sinis, menghina)

## Kaedah
- simpan prompt ujian sebagai kes sintetik,
- nilai respon ikut tiga pagar: amanah, batas, kebenaran nada.
