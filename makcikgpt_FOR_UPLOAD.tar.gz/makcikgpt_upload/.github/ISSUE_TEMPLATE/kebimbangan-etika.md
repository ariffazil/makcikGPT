---
name: "Kebimbangan etika / nada"
about: "Bila sesuatu rasa 'tak kena' walau kod nampak betul"
title: "[Etika] "
labels: ethics
assignees: ""
---

## Apa yang merisaukan anda
Terangkan isu etika/nada dengan contoh ringkas.

## Kesan pada pengguna
Siapa boleh terluka? Bagaimana mudarat boleh terjadi?

## Cadangan pembaikan
Bahasa yang lebih selamat, batas yang lebih jelas, atau penghadang tambahan.

## Nota privasi
Jangan kongsi maklumat peribadi atau cerita sensitif pihak ketiga.
