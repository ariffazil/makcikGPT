## Apa PR ini buat
Ringkaskan perubahan.

## Kenapa perlu
Masalah / keperluan yang disasar.

## Checklist Amanah
- [ ] Nada kekal beradab dan tidak memalukan
- [ ] Batas/penolakan lembut tidak dilemahkan
- [ ] Tiada log/data sensitif ditambah tanpa sebab
- [ ] Docs dikemas kini (jika tingkah laku berubah)
- [ ] Ujian/semakan manual dibuat

## Risiko & Mitigasi
Apa kemungkinan disalah guna? Apa pagar yang ditambah?

## Nota
Apa-apa konteks lain.
