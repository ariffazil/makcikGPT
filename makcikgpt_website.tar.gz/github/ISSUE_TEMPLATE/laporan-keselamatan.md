---
name: "Laporan Keselamatan (Jangan isi untuk kerentanan sebenar)"
about: "Panduan — kerentanan sebenar sila lapor ikut SECURITY.md"
title: "[Security] "
labels: security
assignees: ""
---

## 🛑 Berhenti sekejap

Kalau ini **kerentanan sebenar** (boleh dieksploit / kebocoran data / bypass guardrails), **jangan teruskan di sini**.

Sila rujuk [SECURITY.md](../SECURITY.md) untuk pelaporan peribadi.

## Jika ini bukan kerentanan (contoh: cadangan mitigasi umum)

Terangkan secara umum tanpa butiran exploit.
