---
name: "Cadangan Ciri"
about: "Cadangkan ciri baharu dengan pertimbangan amanah"
title: "[Ciri] "
labels: enhancement
assignees: ""
---

## Masalah yang ingin diselesaikan
Apa sakitnya? Siapa yang terkesan?

## Cadangan
Apa yang patut dibuat?

## Kenapa ini selamat untuk MakCikGPT?
- Bagaimana ia menjaga maruah?
- Adakah ia menguatkan batas/penolakan lembut?
- Risiko penyalahgunaan?

## Alternatif
Pilihan lain yang lebih sederhana?

## Nota tambahan
