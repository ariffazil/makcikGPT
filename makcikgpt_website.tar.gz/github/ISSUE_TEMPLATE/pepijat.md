---
name: "Pepijat (Bug)"
about: "Laporkan bug yang boleh diulang"
title: "[Bug] "
labels: bug
assignees: ""
---

## Apa yang berlaku
Terangkan dengan ringkas.

## Apa yang sepatutnya berlaku
Jangkaan yang betul.

## Cara untuk ulang (reproduce)
1. 
2. 
3. 

## Konteks
- OS / Browser / Runtime:
- Commit/Version:
- Log (jika selamat untuk kongsi, tapis data sensitif):

## Nota Amanah
Adakah isu ini melibatkan data sensitif, prompt-jailbreak, atau potensi mudarat? Jika ya, sila rujuk SECURITY.md dan lapor secara peribadi.
