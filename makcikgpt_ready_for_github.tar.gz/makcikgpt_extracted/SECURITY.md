# Keselamatan & pelaporan isu

> *“Pagar yang rapuh takkan melindungi rumah,  
> tapi pagar yang tak ada pintu, penghuni jadi tawanan.”*

MakCikGPT ada dua jenis keselamatan: **teknikal (kod)** dan **etika (jiwa)**. Kau boleh laporkan dua-dua.

---

## Apa yang kami anggap isu keselamatan

### 🔴 Kritikal (segera)
- Prompt injection / jailbreak yang berjaya:
  - memintas batas hingga keluarkan kandungan berbahaya,
  - mengubah nada jadi toksik/manipulatif,
  - membuka ruang kebocoran data atau arahan berisiko.
- Tanda-tanda sistem menyimpan data sensitif pengguna tanpa izin.

### 🟠 Tinggi
- Mekanisme penolakan rosak (benda patut ditolak tapi terjawab).
- “Tone drift” yang membahayakan (gurau tentang trauma, gaslighting, dll).

### 🟡 Sederhana
- Docs mengelirukan tentang batas.
- Bug UI yang tak jejaskan keselamatan.

---

## Cara melapor

**Jangan** buka isu awam untuk kerentanan yang boleh dieksploit.

Gunakan salah satu:
1) GitHub: tab **Security** → **Report a vulnerability** (jika diaktifkan), atau  
2) Emel projek: `security@CONTOH.DOMAIN` *(gantikan bila siap)*

### Format laporan
Subjek: `[SECURITY] MakCikGPT - <ringkasan>`

1. Tahap: Kritikal/Tinggi/Sederhana  
2. Apa berlaku  
3. Langkah reproduce (ringkas, cukup untuk kami ulang)  
4. Kesan (impact)  
5. Cadangan fix (kalau ada)  

---

## Polisi pendedahan (responsible disclosure)

1) Kau lapor secara peribadi  
2) Kami siasat & sahkan  
3) Kami baiki & uji  
4) Kami release patch  
5) Lepas itu barulah post-mortem (nama kau boleh kekal anonim)

---

## Keselamatan etika

Jika MakCikGPT:
- terlalu patuh pada permintaan manipulatif,
- mengesahkan tindakan mencederakan diri,
- guna “toxic positivity” yang menafikan rasa,

itu juga isu keselamatan. Labelkan `[ETHICAL]` dalam laporan.

---

## Untuk pengguna: perlindungan diri

MakCikGPT **tak akan**:
- minta kata laluan, IC, alamat rumah,
- simpan chat untuk “train model” tanpa persetujuan,
- stalk/mengingat pengguna merentas sesi sebagai lalai.

Kalau kau nampak sebaliknya — itu bug, bukan feature. Lapor.

> *Pagar dibina bukan untuk penjara,  
> tapi supaya anak tak terlepas jatuh ke gaung.*
