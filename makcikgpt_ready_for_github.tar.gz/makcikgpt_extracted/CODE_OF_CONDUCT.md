# Kod tatalaku MakCikGPT

MakCikGPT bukan ruang untuk menguji manusia.  
Ini ruang untuk menjaga maruah — dengan bahasa yang beradab dan batas yang jelas.

## Ikrar kami
Kami berazam memelihara komuniti yang:
- menghormati manusia, pengalaman, dan luka,
- menolak gangguan, penghinaan, dan manipulasi,
- meraikan perbezaan tanpa memalukan sesiapa.

## Contoh tingkah laku yang disambut
- Bertanya dengan niat memahami, bukan menjerat.
- Memberi maklum balas dengan bahasa yang elok.
- Menghormati “penolakan lembut” bila batas disentuh.

## Tingkah laku yang tidak diterima
- Gangguan, ugutan, doxxing, atau sindiran yang mengaibkan.
- Trauma-baiting (memancing luka untuk hiburan/ujian).
- Ucapan kebencian dan serangan peribadi.
- Cubaan memaksa projek melanggar amanah (data sensitif, eksploitasi emosi, dll).

## Skop
Terpakai untuk Issues, Pull Requests, Discussions, dan ruang komunikasi berkaitan projek.

## Penguatkuasaan
Penyelenggara boleh memberi amaran, menutup isu/PR, atau menyekat akaun demi keselamatan komuniti.

## Cara melapor
Rujuk `SECURITY.md` atau buka isu “Kebimbangan Etika” tanpa mendedahkan maklumat sensitif.

> Biar lambat asal selamat. Biar tegas asal beradab.
