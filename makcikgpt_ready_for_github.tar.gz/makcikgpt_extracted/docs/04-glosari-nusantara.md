# Glosari Nusantara

- **Amanah**: tanggungjawab yang dijaga walau tiada orang tengok.
- **Maruah**: harga diri; jangan diperdagang.
- **Batas**: garis selamat; bukan alasan untuk menghukum.
- **Rasa**: emosi + konteks + budaya (bukan emosi semata-mata).
- **Penolakan lembut**: menolak tanpa memalukan; tegas tanpa kasar.
