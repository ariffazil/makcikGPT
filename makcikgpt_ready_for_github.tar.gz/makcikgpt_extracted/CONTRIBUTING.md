# Cara menyumbang kepada MakCikGPT

> *“Bukan siapa-siapa boleh masuk dapur,  
> tapi yang ikhlas belajar, kita ajar.”*

Terima kasih kerana nak bantu jadikan MakCikGPT lebih baik. Tapi sebelum kau hantar *pull request*, baca ini dulu — supaya kita sama halaman.

---

## Apa yang kami alu-alukan

### ✅ Sumbangan yang diterima

**1) Perhalus bahasa & budaya**
- Tambah peribahasa yang sesuai (tapi jangan sampai klise).
- Betulkan nada — kalau bunyi macam “robot cuba jadi manusia”, tegur.
- Terjemahan / variasi dialek Nusantara (dengan adab dan konteks).

**2) Uji keselamatan & batas**
- Cari prompt yang cuba “jailbreak” watak/batas MakCikGPT.
- Laporkan bila penolakan tak cukup tegas (atau terlalu keras).
- Cadangkan test-case untuk situasi sensitif.

**3) Dokumentasi**
- Betulkan typo dan susun semula docs supaya mudah baca.
- Tambah contoh dialog (tanpa data sebenar pengguna).
- Terangkan konsep kepada orang baru.

### ❌ Sumbangan yang ditolak

- Prompt engineering untuk **bypass** batas/penolakan.
- Data pengguna sebenar (walau “anon”). Gunakan data sintetik sahaja.
- Ciri yang merosakkan amanah (contoh: simpan semua chat pengguna untuk personalisasi).

---

## Proses Pull Request

1) **Bincang dulu**  
Untuk perubahan besar, buka *issue* dahulu. Tanya: “Selaras tak dengan tiga pagar?”

2) **Buat perubahan kecil yang boleh disemak**  
PR kecil lebih cepat sampai.

3) **Gunakan checklist PR**
- [ ] Menguatkan amanah/maruah pengguna
- [ ] Tidak melemahkan batas/penolakan
- [ ] Nada kekal beradab (tak memalukan)
- [ ] Tiada data sensitif/log ditambah tanpa sebab kukuh
- [ ] Docs/ujian dikemas kini (jika relevan)

4) **Review**  
Kami akan tanya: *“Ini buat MakCikGPT lebih selamat, atau lebih viral?”*  
Kalau jawapan “viral”, kita fikir semula.

---

## Kod etika penyumbang

Dengan menyumbang, kau setuju untuk:
- Berhemah dalam komunikasi.
- Hormati bahawa Nusantara bukan homogen — sensitif budaya berbeza.
- Utamakan keselamatan pengguna daripada “cool factor”.

---

## FAQ

**Q: Boleh guna MakCikGPT untuk projek komersial?**  
A: Lesen AGPL membenarkan, tapi jika deploy sebagai servis web, kau perlu kongsi kod perubahan. Yang lebih penting: jangan khianat tiga pagar.

**Q: Kenapa MakCikGPT kadang-kadang menolak tegas?**  
A: Sebab ada batas yang tak boleh digoyah, walau pengguna merajuk.

---

*Ditempa bersama, bukan diberi sorang.*
